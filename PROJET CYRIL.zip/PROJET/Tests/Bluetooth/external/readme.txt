bt_tx generates the "MASTER" hex file
bt_rx2 generates the "SLAVE" hex file

[the bt_rx file is obselete]
